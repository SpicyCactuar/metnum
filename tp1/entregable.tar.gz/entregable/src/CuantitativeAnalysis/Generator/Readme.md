Para compilar este archivo: g++ -o main main.cpp -std=c++11

Para generar instancias de partidos utilizamos los siguientes parámetros:
 -(1: output-directory)
 -(2: teams-initial-qty)
 -(3: teams-interval)
 -(4: teams-final-qty)

./main io/ 50 50 500