Para compilar este archivo: g++ -o main main.cpp -std=c++11

Para simular el experimento:
-(n: iterations)
-(o: output file)
-(i: input's input file)

./main 40 io/testsResults.out io/inputs.in