Para compilar este archivo: g++ -o main main.cpp -std=c++11

Para simular los experimentos:
-(i: input file)
-(o: output file)
-(t: team to climb)

./main io/nba_2015_scores.in io/nba_2015_scores_1.out 1;
./main io/nba_2015_scores.in io/nba_2015_scores_2.out 2;
./main io/nba_2015_scores.in io/nba_2015_scores_3.out 3;
./main io/nba_2015_scores.in io/nba_2015_scores_4.out 4;
./main io/nba_2015_scores.in io/nba_2015_scores_5.out 5;
./main io/nba_2015_scores.in io/nba_2015_scores_6.out 6;
./main io/nba_2015_scores.in io/nba_2015_scores_7.out 7;
./main io/nba_2015_scores.in io/nba_2015_scores_8.out 8;
./main io/nba_2015_scores.in io/nba_2015_scores_9.out 9;
./main io/nba_2015_scores.in io/nba_2015_scores_10.out 10;
./main io/nba_2015_scores.in io/nba_2015_scores_11.out 11;
./main io/nba_2015_scores.in io/nba_2015_scores_12.out 12;
./main io/nba_2015_scores.in io/nba_2015_scores_13.out 13;
./main io/nba_2015_scores.in io/nba_2015_scores_14.out 14;
./main io/nba_2015_scores.in io/nba_2015_scores_15.out 15;
./main io/nba_2015_scores.in io/nba_2015_scores_16.out 16;
./main io/nba_2015_scores.in io/nba_2015_scores_17.out 17;
./main io/nba_2015_scores.in io/nba_2015_scores_18.out 18;
./main io/nba_2015_scores.in io/nba_2015_scores_19.out 19;
./main io/nba_2015_scores.in io/nba_2015_scores_20.out 20;
./main io/nba_2015_scores.in io/nba_2015_scores_21.out 21;
./main io/nba_2015_scores.in io/nba_2015_scores_22.out 22;
./main io/nba_2015_scores.in io/nba_2015_scores_23.out 23;
./main io/nba_2015_scores.in io/nba_2015_scores_24.out 24;
./main io/nba_2015_scores.in io/nba_2015_scores_25.out 25;
./main io/nba_2015_scores.in io/nba_2015_scores_26.out 26;
./main io/nba_2015_scores.in io/nba_2015_scores_27.out 27;
./main io/nba_2015_scores.in io/nba_2015_scores_28.out 28;
./main io/nba_2015_scores.in io/nba_2015_scores_29.out 29;
./main io/nba_2015_scores.in io/nba_2015_scores_30.out 30;

./main io/nba_modif.in io/nba_modif1.out 1;
./main io/nba_modif.in io/nba_modif2.out 2;
./main io/nba_modif.in io/nba_modif3.out 3;
./main io/nba_modif.in io/nba_modif4.out 4;
./main io/nba_modif.in io/nba_modif5.out 5;
./main io/nba_modif.in io/nba_modif6.out 6;
./main io/nba_modif.in io/nba_modif7.out 7;
./main io/nba_modif.in io/nba_modif8.out 8;
./main io/nba_modif.in io/nba_modif9.out 9;
./main io/nba_modif.in io/nba_modif10.out 10;
./main io/nba_modif.in io/nba_modif11.out 11;
./main io/nba_modif.in io/nba_modif12.out 12;
./main io/nba_modif.in io/nba_modif13.out 13;
./main io/nba_modif.in io/nba_modif14.out 14;
./main io/nba_modif.in io/nba_modif15.out 15;
./main io/nba_modif.in io/nba_modif16.out 16;
./main io/nba_modif.in io/nba_modif17.out 17;
./main io/nba_modif.in io/nba_modif18.out 18;
./main io/nba_modif.in io/nba_modif19.out 19;
./main io/nba_modif.in io/nba_modif20.out 20;
./main io/nba_modif.in io/nba_modif21.out 21;
./main io/nba_modif.in io/nba_modif22.out 22;
./main io/nba_modif.in io/nba_modif23.out 23;
./main io/nba_modif.in io/nba_modif24.out 24;
./main io/nba_modif.in io/nba_modif25.out 25;
./main io/nba_modif.in io/nba_modif26.out 26;
./main io/nba_modif.in io/nba_modif27.out 27;
./main io/nba_modif.in io/nba_modif28.out 28;
./main io/nba_modif.in io/nba_modif29.out 29;
./main io/nba_modif.in io/nba_modif30.out 30;
