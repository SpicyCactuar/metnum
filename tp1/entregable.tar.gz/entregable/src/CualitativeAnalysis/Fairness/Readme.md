Para compilar este archivo: g++ -o main main.cpp -std=c++11

Para simular el experimento:
-(i: input file)
-(o: output file)

./main io/NoConection/1.in io/NoConection/1.out
./main io/NoGames/1.in io/NoGames/1.out
./main io/NoGames/2.in io/NoGames/2.out
./main io/Strategy/1.in io/Strategy/1.out
./main io/Strategy/2.in io/Strategy/2.out
./main io/Strategy/3.in io/Strategy/3.out
./main io/Unfair/1.in io/Unfair/1.out
./main io/Unfair/2.in io/Unfair/2.out


