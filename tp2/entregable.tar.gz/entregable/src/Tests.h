#ifndef Tests_h
#define Tests_h

void runTests() {
    // TODO: Code
}

#endif