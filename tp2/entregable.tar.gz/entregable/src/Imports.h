#ifndef Imports_h
#define Imports_h

#include <iostream>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <chrono>
#include <map>

using namespace std;

#endif
