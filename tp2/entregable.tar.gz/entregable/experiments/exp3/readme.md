Este main calcula los primeros alpha y gamma autovectores.
Para calcular los de PCA descomentar lineas 38 y 41, comentar lineas 39 y 42.
Para calcular los de PLS-DA descomentar lineas 39 y 42, comentar lineas 38 y 41.
./tp test.in
Luego para cada archivo de salida corremos en script imgmaker.py
(desde la carpeta donde se encuentra)
python imgmaker.py <archivo>
