Este main computa las transformaciones caracteristicas para alpha y gamma = 3.
Luego la imprime.
./tp test.in
