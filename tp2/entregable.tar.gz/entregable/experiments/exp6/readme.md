Este main calcula el promedio de las imagenes de cada digito y los imprime.
./tp test.in
Luego para cada archivo de salida corremos en script imgmaker.py
(desde la carpeta donde se encuentra)
python imgmaker.py <archivo>
