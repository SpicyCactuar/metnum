Este main corre PCA y PLS-DA para los distintos valores de alpha y gamma especificados realizando K Fold Cross Validation.
Luego corre KNN para distintos valores de k.
Genera las estadisticas pertinentes.
./tp test#.in test#.out
