input: 	test1.in
output:	output.txt
alpha: 	10
gamma: 	10
test:  	1