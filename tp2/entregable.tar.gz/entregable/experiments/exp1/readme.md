Este main corre knn sin preprocesamiento alguno.
Genera las estadisticas pertinentes.
./tp test#.in test#.out
