Este main calcula los 784 autovalores de ambos metodos.
Luego imprime la suma de los autovalores 1 a i para i = 1,...,784.
./tp test.in
